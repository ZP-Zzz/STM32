#include "stm32f10x.h"
#include "dma_mtm.h"
#include "led.h"
#include "bsp_SysTick.h"
int main(void)
{	
	uint8_t status=0;
	SysTick_Init();
	Led_Init();
	GPIO_ResetBits(GPIOB,GPIO_Pin_1);
	SysTick_Delay_Ms(1000);
	DMA_MTM_Init();
	
	while(DMA_GetFlagStatus(DMA1_FLAG_TC6)==0);   // ==RESET,��ʾû�д���ɹ�  (  �ж���û�д������)
	
	status=Buffercmp(aSRC_Const_Buffer,aDST_Buffer,32);   //�ж���û�д���ɹ�
	if(status==0)
	{
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
	}
	else
	{
		GPIO_ResetBits(GPIOB,GPIO_Pin_0);
	}
	while(1)
	{
		
	}
}


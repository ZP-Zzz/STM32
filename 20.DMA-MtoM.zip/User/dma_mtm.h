#ifndef __dma_mtm_H__
#define __dma_mtm_H__

extern uint32_t aDST_Buffer[32]; 

extern const uint32_t aSRC_Const_Buffer[32];



void DMA_MTM_Init(void);
uint8_t Buffercmp(const uint32_t* pBuffer,uint32_t* pBuffer1, uint16_t BufferLength);
#endif


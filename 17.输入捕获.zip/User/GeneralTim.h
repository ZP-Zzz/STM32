#ifndef __GeneralTim_H__
#define __GeneralTim_H__



void TIM5_Cap_Init(u16 arr,u16 psc);


#endif


#include "stm32f10x.h"
#include "OLED_I2C.h"
#include "bsp_SysTick.h"

extern const unsigned char BMP_1[],BMP_2[],BMP_3[],BMP_4[],BMP_5[],BMP_6[],BMP_7[],BMP_8[],BMP_9[],BMP_10[],BMP_11[],BMP_13[],BMP_14[],BMP_15[],BMP_16[],BMP_17[],BMP_18[],BMP_19[],BMP_20[],BMP_21[],BMP_22[],BMP_23[],BMP_24[],BMP_12[];

int main(void)
{	
	unsigned char i,j=5;
	SysTick_Init(); 
	I2C_Configuration();//����CPU��Ӳ��I2C
	OLED_Init();
	OLED_Fill(0xFF);//ȫ������
	SysTick_Delay_Ms(2000);		// 2s
	OLED_Fill(0x00);//ȫ����
	SysTick_Delay_Ms(1000);		// 2s
	
	while(1)
	{

		
//		for(i=0;i<4;i++)
//		{
//			OLED_ShowCN(22+i*16,0,i);		//������ʾ���ģ������꣬�����꣬�ֵı�ţ�
//		}	
		OLED_ShowCN(0,1,0);  //x:0~127, y:0~7
		OLED_ShowCN(20,1,1);
		OLED_ShowCN(40,1,2);
		OLED_ShowCN(60,1,3);
		OLED_ShowCN(80,1,4);
		SysTick_Delay_Ms(1000);
		for(i=0;i<80;i++)
		{
			OLED_ShowStr(i,5,"LOVE YOU",1);
			SysTick_Delay_Ms(100);	
			OLED_ShowStr(i,5,"        ",1);	
		}
		
//		SysTick_Delay_Ms(2000);		// 1s
		OLED_CLS();//����
		
		
//		OLED_ShowStr(0,0,"Wildfire Tech",1);		 //�ַ���С(1:6*8 ; 2:8*16)		
//		OLED_ShowStr(0,1,"Hello wildfire",1);		//�ַ���С(1:6*8 ; 2:8*16)	
//		SysTick_Delay_Ms(2000);		// 2*100=200s
//		OLED_CLS();//����
		
		
		
		while(j--)
		{
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_1);//����BMPλͼ��ʾ
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_2);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_3);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_4);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_5);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_6);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_7);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_8);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_9);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_10);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_11);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_12);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_13);//����BMPλͼ��ʾ
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_14);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_15);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_16);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_17);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_18);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_19);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_20);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_21);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_22);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_23);
			OLED_DrawBMP(0,0,128,8,(unsigned char *)BMP_24);
		}

		OLED_CLS();//����
		}
}


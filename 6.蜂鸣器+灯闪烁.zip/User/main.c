#include "stm32f10x.h"
#include "bps_bee.h"


void delay(__IO uint32_t i)
{
	for(;i!=0;i--);
}


int main(void)
{
	Bee_Init();
	while(1)
	{
		GPIO_SetBits(GPIOA,GPIO_Pin_8);
		GPIO_SetBits(GPIOB,GPIO_Pin_0);
		delay(1000000);
		
		
		GPIO_ResetBits(GPIOA,GPIO_Pin_8);
		GPIO_ResetBits(GPIOB,GPIO_Pin_0);
		delay(1000000);
		
		
		
	}
}


#ifndef __bps_bee_H__
#define __bps_bee_H__


void Bee_Init(void);

#endif


#ifndef __timer_pwm_H__
#define __timer_pwm_H__
#include "stm32f10x.h"
//void TIMER3_Init(u16 arr,u16 psc);

void TIMER3_PWM_Init(u16 arr,u16 psc);
#endif


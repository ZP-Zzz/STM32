#include "stm32f10x.h"
#include "led.h"
#include "timer_pwm.h"
#include "bsp_SysTick.h"

int main(void)
{
	u16 Compare_Value=0;
	u8 flag=1;
	Led_Init();
	SysTick_Init();
	TIMER3_PWM_Init(899,0);  //����Ƶ��PWMƵ��Ϊ72000000/900=80KHz
	while(1)
	{
		SysTick_Delay_Ms(1);   //��ʱһ�£����򿴲���Ч��
		if(flag==1)
		{
			Compare_Value++;
		}
		else
		{
			Compare_Value--;
		}
		if(Compare_Value>300)
		{
			flag=0;
		}
		if(Compare_Value==0)
		{
			flag=1;
		}
		
		TIM_SetCompare2(TIM3,Compare_Value);   //�Ƚ�ֵ
		
	}
}


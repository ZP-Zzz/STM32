#ifndef __adc_H__
#define __adc_H__

void ADCx_Init(void);

#endif

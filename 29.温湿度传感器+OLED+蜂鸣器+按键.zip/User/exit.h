#ifndef __exit_H__
#define __exit_H__

void EXIT_Init(void);
#endif


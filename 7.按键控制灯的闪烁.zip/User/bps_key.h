#ifndef __bps_key_H__
#define __bps_key_H__

void Key_Init(void);

uint8_t Key_Scan(void);

void delay(int32_t i);

#endif


#ifndef __dma_mtp_H__
#define __dma_mtp_H__


extern uint8_t SendBuff[5000];

void DMA_MTP_Init(void);

#endif


#include "stm32f10x.h"
#include "led.h"
#include "bsp_SysTick.h"
#include "dma_mtp.h"
#include "usart.h"

int main(void)
{
	uint16_t i=0;
	for(i=0;i<5000;i++)
	{
		SendBuff[i]='p';
	}
	
	USART_Config();
	DMA_MTP_Init();
	USART_DMACmd(USART1,USART_DMAReq_Tx,ENABLE);
	while(1)
	{
		
		
	}
}


#include "stm32f10x.h"
#include "usart.h"
#include "bps_led.h"


int main(void)
{	

	USART_Config();
	Led_Init();
	
	while(1)
	{		     
		switch(Temp)
		{
			case 1:GPIO_ResetBits(GPIOB,GPIO_Pin_5);
					 GPIO_SetBits(GPIOB,GPIO_Pin_0);
					 GPIO_SetBits(GPIOB,GPIO_Pin_1);
					 break;
			case 2:GPIO_SetBits(GPIOB,GPIO_Pin_5);
					 GPIO_SetBits(GPIOB,GPIO_Pin_0);
					 GPIO_ResetBits(GPIOB,GPIO_Pin_1);
					 break;
			case 3:GPIO_SetBits(GPIOB,GPIO_Pin_5);
					 GPIO_ResetBits(GPIOB,GPIO_Pin_0);
					 GPIO_SetBits(GPIOB,GPIO_Pin_1);
					 break;
			default:GPIO_SetBits(GPIOB,GPIO_Pin_5);  //����IO��,���ߵ�ƽ(�ر�)
					GPIO_SetBits(GPIOB,GPIO_Pin_0);  //����IO��,���ߵ�ƽ(�ر�)
					GPIO_SetBits(GPIOB,GPIO_Pin_1);  //����IO��,���ߵ�ƽ(�ر�)
					break;
		}
	}
}


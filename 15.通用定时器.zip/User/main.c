#include "stm32f10x.h"
#include "led.h"
#include "timer.h"
#include "stm32f10x.h"

int main(void)
{
	Led_Init();
	TIMER3_Init(4999,7199);   //500ms��תһ��led
	while(1)
	{
		
		
	}
}


#ifndef __timer_H__
#define __timer_H__
#include "stm32f10x.h"
void TIMER3_Init(u16 arr,u16 psc);

#endif


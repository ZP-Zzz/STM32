#include "stm32f10x.h"
#include "bps_led.h"
#include "bsp_SysTick.h"

int main(void)
{	
	Led_Init();
	SysTick_Init();
	while(1)
	{
		GPIO_ResetBits(GPIOB,GPIO_Pin_1);   //ResetBits  ��IO��
		SysTick_Delay_Ms(1000);
		GPIO_SetBits(GPIOB,GPIO_Pin_1);   //SetBits  �ر�IO��
		
		GPIO_ResetBits(GPIOB,GPIO_Pin_0);
		SysTick_Delay_Ms(1000);
		GPIO_SetBits(GPIOB,GPIO_Pin_0);
		
		GPIO_ResetBits(GPIOB,GPIO_Pin_5);
		SysTick_Delay_Ms(1000);
		GPIO_SetBits(GPIOB,GPIO_Pin_5);
	}
}



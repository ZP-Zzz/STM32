#ifndef __usart_H__
#define __usart_H__

void USART_Config(void);
//void USRAT_Init(void);
//void USART1_IRQHandler(void);
//void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
#endif


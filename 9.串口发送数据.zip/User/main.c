#include "stm32f10x.h"
#include "bsp_SysTick.h"
#include "usart.h"

int main(void)
{
	
	USART_Config();
	while(1)
	{
		
	}
	
}


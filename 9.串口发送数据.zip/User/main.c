#include "stm32f10x.h"
#include "usart.h"

int main(void)
{	
	USART_Config();
//	Usart_SendByte('a');
//	Usart_SendByte(0x0a);    //0x0aΪ����
//	Usart_SendString("421054868");
	printf("421054868");
	
	while(1)
	{
		
	}
}


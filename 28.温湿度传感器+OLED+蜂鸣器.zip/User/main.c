#include "stm32f10x.h"
#include "dht11.h"
#include "led.h"
#include "OLED_I2C.h"
#include "usart.h"
#include "bsp_SysTick.h"
#include "GeneralTim2.h"
#include "GeneralTim3.h"
#include "beep.h" 

unsigned  char cStr1 [ 100 ]; //dh11 ʪ��
unsigned  char cStr2 [ 100 ];//dh11 �¶�
unsigned char BeepFlag=0;

int main(void)
{
	SysTick_Init(); 
	Led_Init();
	I2C_Configuration();//����CPU��Ӳ��I2C
	OLED_Init();
	USART_Config();
	DHT11_Init ();
	GENERAL_TIM2_Init();
	GENERAL_TIM3_Init();
	BEEP_GPIO_Config();
	printf("�����¶���ʪ��\n");
	OLED_Fill(0xFF);//ȫ������
	SysTick_Delay_Ms(1000);		// 2s
	OLED_Fill(0x00);//ȫ����
	SysTick_Delay_Ms(1000);		// 2s
	while(1)
	{	

		DHT11_Data_TypeDef DHT11_Data;
		/*����DHT11_Read_TempAndHumidity��ȡ��ʪ�ȣ����ɹ����������Ϣ*/
		if( DHT11_Read_TempAndHumidity ( & DHT11_Data ) == SUCCESS)
		{
			printf("\r\n��ȡDHT11�ɹ�!\r\n\r\nʪ��Ϊ%d.%d ��RH ���¶�Ϊ %d.%d�� \r\n",DHT11_Data.humi_int,DHT11_Data.humi_deci,DHT11_Data.temp_int,DHT11_Data.temp_deci); 
			if(DHT11_Data.humi_int>=80 || DHT11_Data.temp_int>=30)
			{
				BeepFlag=1;
			}
			else
			{
				BeepFlag=0;
			}
				
            sprintf ( (char*)cStr1, "%d.%d ",DHT11_Data.humi_int,DHT11_Data.humi_deci);
            sprintf ( (char*)cStr2, "%d.%d ",DHT11_Data.temp_int,DHT11_Data.temp_deci);
		}			
		else
		{
			printf("Read DHT11 ERROR!\r\n");
		}
		
		SysTick_Delay_Ms(2000);


	}
}


#ifndef __i2c_H__
#define __i2c_H__

void i2c_Init(void);
void EEPROM_ReadByte(uint8_t add,uint8_t *data,uint8_t numByte);  //numByte�����ٸ��ֽ�
void EEPROM_WriteByte(uint8_t add,uint8_t data);
void EEPROM_Wait_For_WriteEnd(void);
void EEPROM_Write_Page_Byte(uint8_t add,uint8_t *data,uint8_t numByte_To_Write);

#endif


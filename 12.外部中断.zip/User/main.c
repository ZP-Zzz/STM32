#include "stm32f10x.h"
#include "bsp_SysTick.h"
#include "exit.h"
#include "led.h"
#include "key.h"

int main(void)
{
	SysTick_Init();   
	EXIT_Init();
	Led_Init();
	Key_GPIO_Config();
	while(1)
	{
		
		
	}
}


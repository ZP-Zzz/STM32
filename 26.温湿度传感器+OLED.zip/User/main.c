#include "stm32f10x.h"
#include "dht11.h"
#include "led.h"
#include "OLED_I2C.h"
#include "usart.h"
#include "bsp_SysTick.h"

unsigned  char cStr1 [ 100 ]; //dh11 ʪ��
unsigned  char cStr2 [ 100 ];//dh11 �¶�

float temperature1;
float temperature2;


int main(void)
{
	SysTick_Init(); 
	Led_Init();
	I2C_Configuration();//����CPU��Ӳ��I2C
	OLED_Init();
	USART_Config();
	DHT11_Init ();
	printf("�����¶���ʪ��\n");
	OLED_Fill(0xFF);//ȫ������
	SysTick_Delay_Ms(1000);		// 2s
	OLED_Fill(0x00);//ȫ����
	SysTick_Delay_Ms(1000);		// 2s
	while(1)
	{	

		DHT11_Data_TypeDef DHT11_Data;
		/*����DHT11_Read_TempAndHumidity��ȡ��ʪ�ȣ����ɹ����������Ϣ*/
		if( DHT11_Read_TempAndHumidity ( & DHT11_Data ) == SUCCESS)
		{
			printf("\r\n��ȡDHT11�ɹ�!\r\n\r\nʪ��Ϊ%d.%d ��RH ���¶�Ϊ %d.%d�� \r\n",DHT11_Data.humi_int,DHT11_Data.humi_deci,DHT11_Data.temp_int,DHT11_Data.temp_deci);
			temperature1=DHT11_Data.humi_int+DHT11_Data.humi_deci;                       
            temperature2=DHT11_Data.temp_int+DHT11_Data.temp_deci;      
            sprintf ( (char*)cStr1, "%0.1f ", temperature1);
            sprintf ( (char*)cStr2, "%0.1f", temperature2);
		}			
		else
		{
			printf("Read DHT11 ERROR!\r\n");
		}
		
		SysTick_Delay_Ms(2000);

		OLED_ShowCN(10,1,0);  //x:0~127, y:0~7
		OLED_ShowCN(30,1,1);
		OLED_ShowStr(50,1,cStr2,2);
		
		OLED_ShowCN(10,4,2);
		OLED_ShowCN(30,4,3);
		OLED_ShowStr(50,4,cStr1,2);
		GPIOB->ODR ^=GPIO_Pin_0;
	}
}

